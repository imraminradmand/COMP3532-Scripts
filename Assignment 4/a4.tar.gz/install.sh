#!/bin/bash 


sudo cp ./passgen.1.gz /usr/share/man/man1 
sudo mandb
